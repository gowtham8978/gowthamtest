export const slackWebhookUrl = ''
